import express from "express";
import jwt from "jsonwebtoken";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

const JWT_SECRET = "super_secret_key";

app.post("/login", (req, res) => {
  const { email, password } = req.body;

  if (email !== "admin@test.com" || password !== "123456") {
    return res.status(401).json({ message: "Invalid credentials" });
  }

  const token = jwt.sign({ email, role: "ADMIN" }, JWT_SECRET, {
    expiresIn: "1h",
  });

  res.json({ token });
});

app.listen(5000, () => {
  console.log("Backend running on http://localhost:5000");
});
