import { Button, Table } from "@mui/material";

export default function ReconciliationTable() {
  return (
    <Table>
      {/* Filename | Reconciliation | Status | Checkbox | Approve */}
    </Table>
  );
}
